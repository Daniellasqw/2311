
const result = document.querySelector('h2');
// const btn = document.getElementById('btn');
const frm = document.querySelector('form');


// btn.addEventListener('click', function (){

//     let name = document.getElementById('aluno');
//     let bim1 = document.getElementById('bim1');
//     let bim2 = document.getElementById('bim2');
//     let bim3 = document.getElementById('bim3');
//     let bim4 = document.getElementById('bim4');
//     let media = 0;
    
//         media = (parseFloat(bim1.value) + parseFloat(bim2.value) + parseFloat(bim3.value)+ parseFloat(bim4.value))/4
    
//         result.innerText = `O aluno ${name.value} obteve média de ${media}.` 
    

// })

frm.addEventListener('submit', (e)=>{

    const name = frm.aluno.value;
    const bim1 = Number(frm.bim1.value.replace(',','.'));
    const bim2 = Number(frm.bim2.value.replace(',','.'));
    const bim3 = Number(frm.bim3.value.replace(',','.'));
    const bim4 = Number(frm.bim4.value.replace(',','.'));
    let media = (bim1 + bim2 + bim3 + bim4)/4;
        result.innerText = `O aluno ${name} obteve uma média de ${media}` 
        e.preventDefault()

})