objString =JSON.stringify(
  {
    "cor": "amarela",
    "acesa":false
  });